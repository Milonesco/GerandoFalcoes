﻿public class TipoUsuarioDto
{
    public int IdTipoUsuario { get; set; }
    public string DescricaoTipoUsuario { get; set; }
}
