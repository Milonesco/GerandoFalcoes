﻿public class UnidadeDto
{
    public int IdUnidade { get; set; }
    public string Nome { get; set; }
}
