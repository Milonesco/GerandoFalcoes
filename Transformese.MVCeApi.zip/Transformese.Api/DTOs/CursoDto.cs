﻿public class CursoDto
{
    public int IdCurso { get; set; }
    public string Nome { get; set; }
    public string Descricao { get; set; }
    public string? Imagem { get; set; }

    public int UnidadeId { get; set; }
    public string UnidadeNome { get; set; }
}
