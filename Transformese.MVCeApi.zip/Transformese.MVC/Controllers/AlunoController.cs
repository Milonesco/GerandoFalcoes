﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Transformese.Data;

namespace TransformeSeMVC.Web.Controllers
{
    [Authorize(Roles = "Aluno")] // Mantém a role, se quiser controle de acesso
    public class AlunoController : Controller
    {
        private readonly ApplicationDbContext _context; // Usa o novo contexto unificado

        // Injeta o contexto configurado no Program.cs
        public AlunoController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: /Aluno/
        public async Task<IActionResult> Index()
        {
            // Inclui o relacionamento com Unidade (ou outros dados relacionados)
            var cursos = await _context.Cursos
                .Include(c => c.Unidade)
                .ToListAsync();

            // Retorna os dados para a view
            return View(cursos);
        }
    }
}
