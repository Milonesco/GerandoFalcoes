﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Transformese.Data;

namespace TransformeseMVC.Web.Controllers
{
    [Authorize(Roles = "Administrador")]
    public class DashboardController : Controller
    {
        private readonly ApplicationDbContext _context;  // ✅ Substitui ApplicationDbContext por ApplicationDbContext
        public DashboardController(ApplicationDbContext context) => _context = context;

        public async Task<IActionResult> Index()
        {
            // Total de cursos cadastrados
            var totalCursos = await _context.Cursos.CountAsync();

            // Total de usuários do tipo Aluno
            var totalAlunos = await _context.Usuarios
                .CountAsync(u => u.TipoUsuario.DescricaoTipoUsuario == "Aluno");

            // Total de usuários do tipo Professor
            var totalProfessores = await _context.Usuarios
                .CountAsync(u => u.TipoUsuario.DescricaoTipoUsuario == "Professor");

            // Total de usuários do tipo Administrador
            var totalAdministradores = await _context.Usuarios
                .CountAsync(u => u.TipoUsuario.DescricaoTipoUsuario == "Administrador");

            // Envia os valores para a View
            ViewBag.TotalCursos = totalCursos;
            ViewBag.TotalAlunos = totalAlunos;
            ViewBag.TotalProfessores = totalProfessores;
            ViewBag.TotalAdministradores = totalAdministradores;

            return View();
        }

    }
}
