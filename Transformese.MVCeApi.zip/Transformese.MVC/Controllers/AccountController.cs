﻿using Microsoft.AspNetCore.Mvc;
using Transformese.Data.Repositories;
using Transformese.Domain.Entities;

namespace TransformeSeMVC.Web.Controllers
{
    public class AccountController : Controller
    {
        private readonly UsuarioRepository _repo;

        public AccountController(UsuarioRepository repo)
        {
            _repo = repo;
        }

        [HttpGet]
        public IActionResult Login() => View();

        [HttpPost]
        public async Task<IActionResult> Login(string email, string senha)
        {
            var usuario = await _repo.AutenticarAsync(email, senha);
            if (usuario == null)
            {
                ViewBag.Error = "Usuário ou senha inválidos.";
                return View();
            }

            // Sessão simples (pode ser substituída por JWT no mobile)
            HttpContext.Session.SetString("Usuario", usuario.Email);
            HttpContext.Session.SetString("TipoUsuario", usuario.TipoUsuario.DescricaoTipoUsuario);

            // Redireciona baseado no tipo
            if (usuario.TipoUsuario.DescricaoTipoUsuario == "Administrador")
                return RedirectToAction("Index", "Dashboard");
            if (usuario.TipoUsuario.DescricaoTipoUsuario == "Professor")
                return RedirectToAction("Index", "Professor");

            return RedirectToAction("Index", "Aluno");
        }

        [HttpGet]
        public IActionResult Register() => View();

        [HttpPost]
        public async Task<IActionResult> Register(Usuario model)
        {
            if (!ModelState.IsValid)
                return View(model);

            await _repo.AddAsync(model);
            return RedirectToAction(nameof(Login));
        }

        [HttpPost]
        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction(nameof(Login));
        }
    }
}
