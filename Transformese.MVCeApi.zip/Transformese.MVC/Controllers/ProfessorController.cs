﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Transformese.Data;

namespace TransformeseMVC.Web.Controllers
{
    [Authorize(Roles = "Professor")]
    public class ProfessorController : Controller
    {
        private readonly ApplicationDbContext _context;
        public ProfessorController(ApplicationDbContext context) => _context = context;

        public async Task<IActionResult> Index()
        {
            var turmas = await _context.Cursos.Include(c => c.Unidade).ToListAsync();
            return View(turmas);
        }
    }
}
