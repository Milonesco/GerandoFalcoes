﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Transformese.Data;

namespace TransformeSeMVC.Web.Controllers
{
    public class CursoController : Controller
    {
        private readonly ApplicationDbContext _context;  // ✅ Substitui ApplicationDbContext por ApplicationDbContext

        public CursoController(ApplicationDbContext context)
        {
            _context = context;
        }

        // 🔹 Lista (GET /Curso)
        [HttpGet]
        public async Task<IActionResult> Index()
        {
            var cursos = await _context.Cursos
                .Include(c => c.Unidade)
                .ToListAsync();

            return View(cursos);
        }

        // 🔹 Exibe detalhes do curso
        public async Task<IActionResult> Detalhes(int id)
        {
            var curso = await _context.Cursos
                .Include(c => c.Unidade)
                .FirstOrDefaultAsync(c => c.IdCurso == id);

            if (curso == null)
                return NotFound();

            return PartialView("_DetalhesCursoPartial", curso);
        }

        // 🔹 Endpoint para exibir detalhes no modal (AJAX)
        [HttpGet]
        public async Task<IActionResult> DetalhesModal(int id)
        {
            var curso = await _context.Cursos
                .Include(c => c.Unidade)
                .AsNoTracking()
                .FirstOrDefaultAsync(c => c.IdCurso == id);

            if (curso == null)
                return NotFound();

            var imagem = "/images/default-course.jpg";

            return Json(new
            {
                id = curso.IdCurso,
                titulo = curso.Nome,                      // ✅ Corrigido: propriedade correta do DTO
                descricao = curso.Descricao,             // ✅ Usa o método Info() da classe DTO
                unidade = curso.Unidade?.Nome ?? "Não informada",
                imagem
            });
        }
    }
}
