using Microsoft.EntityFrameworkCore;
using Transformese.Data;
using Transformese.Data.Repositories;

var builder = WebApplication.CreateBuilder(args);

// DbContext
builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

// HttpContextAccessor necess�rio para _Layout.cshtml
builder.Services.AddHttpContextAccessor();

// Reposit�rios
builder.Services.AddScoped<UsuarioRepository>();
builder.Services.AddScoped<CursoRepository>();
builder.Services.AddScoped<UnidadeRepository>();


// MVC + Session
builder.Services.AddControllersWithViews();
builder.Services.AddSession();

// BUILD
var app = builder.Build();

// ENV
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

// MIDDLEWARES
app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();
app.UseSession();


// ROTA PADR�O
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
